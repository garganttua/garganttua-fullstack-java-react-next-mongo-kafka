package ${packageName}.${projectName}.backend.api.security.authorizations;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.garganttua.api.spec.dto.annotations.GGAPIDto;
import com.garganttua.api.spec.dto.annotations.GGAPIDtoTenantId;
import com.garganttua.objects.mapper.annotations.GGFieldMappingRule;
import ${packageName}.${projectName}.backend.api.security.keys.KeyRealmDto;

@Document(collection = "authorizations")
@GGAPIDto(entityClass = AuthorizationEntity.class, db = "gg:SpringMongoDao")
public class AuthorizationDto {
	
	@Id
	@GGFieldMappingRule(sourceFieldAddress = "uuid")
	private String uuid;
	
	@Field
	@GGFieldMappingRule(sourceFieldAddress = "id")
	protected String id;
	
	@Field
	@GGAPIDtoTenantId
	@GGFieldMappingRule(sourceFieldAddress = "tenantId")
	protected String tenantId;
	
	@Field
	@GGFieldMappingRule(sourceFieldAddress = "signature")
	private byte[] signature = null;

	@Field
	@GGFieldMappingRule(sourceFieldAddress = "raw")
	private byte[] raw = null;

	@DBRef
	@GGFieldMappingRule(sourceFieldAddress = "key")
	protected KeyRealmDto key = null;
	
	@Field
	@GGFieldMappingRule(sourceFieldAddress = "ownerId")
	protected String ownerId;

	@Field
	@GGFieldMappingRule(sourceFieldAddress = "authorities")
	protected List<String> authorities;
	
	@Field
	@GGFieldMappingRule(sourceFieldAddress = "creationDate")
	protected Date creationDate;

	@Field
	@GGFieldMappingRule(sourceFieldAddress = "expirationDate")
	protected Date expirationDate;

	@Field
	@GGFieldMappingRule(sourceFieldAddress = "revoked")
	protected boolean revoked = false;
}
