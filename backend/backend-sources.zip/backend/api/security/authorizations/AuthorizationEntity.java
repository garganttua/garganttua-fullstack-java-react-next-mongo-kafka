package ${packageName}.${projectName}.backend.api.security.authorizations;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.garganttua.api.core.security.authentication.authorization.GGAPIAuthorizationAuthentication;
import com.garganttua.api.core.security.authorization.jwt.GGAPIJWTAuthorization;
import com.garganttua.api.security.authorizations.protocols.bearer.GGAPISpringSecurityAuthorizationProtocolHttpBearer;
import com.garganttua.api.spec.GGAPIException;
import com.garganttua.api.spec.entity.annotations.GGAPIEntity;
import com.garganttua.api.spec.security.annotations.GGAPIAuthenticator;
import com.garganttua.api.spec.security.annotations.GGAPIAuthorization;
import com.garganttua.api.spec.security.annotations.GGAPIEntitySecurity;
import com.garganttua.api.spec.security.authenticator.GGAPIAuthenticatorScope;
import com.garganttua.api.spec.security.key.IGGAPIKeyRealm;

import lombok.NoArgsConstructor;

@GGAPIEntity(domain = "authorizations", interfaces = { "gg:SpringRestInterface" })
@GGAPIAuthorization(signable = true)
@NoArgsConstructor
@GGAPIAuthenticator(scope = GGAPIAuthenticatorScope.system, authentications = GGAPIAuthorizationAuthentication.class)
@GGAPIEntitySecurity(authorizations = { AuthorizationEntity.class }, authorizationProtocols = {
		GGAPISpringSecurityAuthorizationProtocolHttpBearer.class })
@JsonIgnoreProperties(value = { "gotFromRepository", "saveMethod", "deleteMethod", "repository", "save", "delete",
		"engine" })
public class AuthorizationEntity extends GGAPIJWTAuthorization {

	public AuthorizationEntity(byte[] raw, IGGAPIKeyRealm realm) throws GGAPIException {
		super(raw, realm);
	}

	public AuthorizationEntity(String uuid, String id, String tenantId, String ownerUuid, List<String> authorities,
			Date creationDate, Date expirationDate, IGGAPIKeyRealm keyRealm) throws GGAPIException {
		super(uuid, id, tenantId, ownerUuid, authorities, creationDate, expirationDate, keyRealm);
	}
}
