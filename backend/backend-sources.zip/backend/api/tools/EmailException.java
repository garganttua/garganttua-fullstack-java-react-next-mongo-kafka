package ${packageName}.${projectName}.backend.api.tools;

public class EmailException extends Exception {

	public EmailException(String string) {
		super(string);
	}

	private static final long serialVersionUID = 8325304684216456527L;

}
